from setuptools import setup

setup( 
    author= "Fernando_Agustoni ",
    author_email= "fjaguston@gmail.com",
    description= "paquete redistribuible",
    version="0.0.2",
    name="Trabajo_2",
    packages=['Trabajo2']
)