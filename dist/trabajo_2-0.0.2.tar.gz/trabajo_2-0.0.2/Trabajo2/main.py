from Trabajo2.modulo import *

Diccionario= {}

x= Cliente ("Fer", "Ferchu",23772458,"fjafgjñlk@gmail")

print (Diccionario)

x.AgregarAlDiccionario (Diccionario)
print (Diccionario)

x.cambiarContraseña ("Tomi")

print (Diccionario)


